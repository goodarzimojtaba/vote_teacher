<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پیام</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/style_mobile.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="" alt="">
        </div>
        <style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>

        <h4 style="font-family:Vazir;color:red;">شما قبلا به این معلم امتیاز داده اید،جهت ادامه ی کار، معلم دیگری را انتخاب نمایید.</h4>
        <br>
        <a style="font-family:Vazir" href="<?php echo e(route('surveys.index')); ?>" name="submit" class="signup-btn">نظر به سایر معلمان</a>
    </div>
</body>
</html>
<?php /**PATH G:\Laravel\Poll-yarjani\poll-yarjani\resources\views/valid_request.blade.php ENDPATH**/ ?>