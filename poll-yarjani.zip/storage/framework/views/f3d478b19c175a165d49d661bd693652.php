<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>شروع نظرسنجی</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/style_mobile.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="" alt="">
        </div>
        <style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>
        <h2 style="font-family:Vazir">نظرسنجی</h2>
        <h4 style="font-family:Vazir;color:green;">دانش آموز عزیز می توانید در شاخص های مربوطه از 1 تا 5 به معلم تان امتیاز بدهید، 5 بالاترین امتیاز و 1 کمترین امتیاز است.</h4>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label style="font-family:Vazir"><?php echo e($error); ?></label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('surveys.store')); ?>">
            <?php echo csrf_field(); ?>
                <label  style="font-family:Vazir;text-align:center;" class="fas fa-eye-slash" >ابتدا معلم مورد نظر را انتخاب نمایید</label>
                <div class="password-container">
                <select class="password-container" name="teacher_id" id="teacher_id"
                style="font-family:Vazir; text-align:center; width:300px;">
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($teacher->id); ?>" style="font-family:Vazir;text-align:center;"><?php echo e($teacher->user->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
        <br>
               
                <label  style="font-family:Vazir;text-align:center;" >سطح علمی</label>
            <div class="password-container">
            <input type="number" name="knowledge_level" id="knowledge_level" class="form-control" min="1" max="5" required>  
            <?php $__errorArgs = ['knowledge_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>       
                   <i class="fas fa-eye-slash"></i>
                <label  style="font-family:Vazir;text-align:center;">روش تدریس</label>
            <div class="password-container">
            <input type="number" name="teaching_style" id="teaching_style" class="form-control" min="1" max="5" required>
            <?php $__errorArgs = ['teaching_style'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <i class="fas fa-eye-slash"></i>
                <label  style="font-family:Vazir;text-align:center;" >رفتار و اخلاق</label>
            <div class="password-container">
            <input type="number" name="behavior" id="behavior" class="form-control" min="1" max="5" required> 
            <?php $__errorArgs = ['behavior'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>               
            <i class="fas fa-eye-slash"></i>
                <label  style="font-family:Vazir;text-align:center;" >وقت شناسی و بازدهی کلاس</label>
            <div class="password-container">
            <input type="number" name="punctuality" id="punctuality" class="form-control" min="1" max="5" required>
            <?php $__errorArgs = ['punctuality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <i class="fas fa-eye-slash"></i>
                <label  style="font-family:Vazir;text-align:center;" >در صورت داشتن انتقاد و پیشنهادی در خصوص راجع این معلم در کادر زیر بنویسید</label>
            <div class="password-container">
            <textarea style="font-family:Vazir;width:300px;text-align:right;" name="comment" id="comment" class="form-control"  rows="3"></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <i class="fas fa-eye-slash"></i>
            </div>

            <button style="font-family:Vazir" type="submit" name="submit" class="signup-btn">ثبت نظر </button>
            <p style="font-family:Vazir;Font-size:12px;text-align:center;">Developed by: Mojtaba Goodarzi</p>
        </form>
    </div>
</body>
</html>
<?php /**PATH G:\Laravel\Poll-yarjani\poll-yarjani\resources\views/surveys/index.blade.php ENDPATH**/ ?>