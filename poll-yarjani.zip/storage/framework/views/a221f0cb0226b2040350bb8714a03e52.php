<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پیام</title>
    <link rel="stylesheet" href="https://yarjani19.com/assets/style_mobile.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="" alt="">
        </div>
        <style>
            @font-face {
                font-family: "Vazir";
                src: url("https://yarjani19.com/mark/fonts/Vazir.ttf")format("Truetype");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff")format("woff");
                src: url("https://yarjani19.com/mark/fonts/Vazir.woff2")format("woff2");
            }
            </style>

        <h4 style="font-family:Vazir;color:green;">نظر شما برای این معلم با موفقیت ثبت گردید با کلیک بر دکمه ی زیر می توانید به سایر معلمان تان هم امتیاز دهید.</h4>
        <br>
        <a style="font-family:Vazir" href="<?php echo e(route('surveys.index')); ?>" name="submit" class="signup-btn">نظر به سایر معلمان</a>
        <a style="font-family:Vazir" href="<?php echo e(route('login1')); ?>" name="submit" class="signup-btn">خروج از سامانه</a>

    </div>
</body>
</html>
<?php /**PATH G:\Laravel\Poll-yarjani\poll-yarjani\resources\views/message.blade.php ENDPATH**/ ?>